module.exports = {
    // mongoURI: "mongodb+srv://bob:VIPRIJ5HMgDQ4kiC@connect4.5jslh.mongodb.net/connect4db?retryWrites=true&w=majority",
    mongoURI: "mongodb://localhost:27017/connect4project",
    secretOrKey: "secret"
  };
